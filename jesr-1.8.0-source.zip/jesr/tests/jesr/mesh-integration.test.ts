import { test } from "node:test";
import assert from "node:assert/strict";
import { JesrEngine } from "../../lib/jesr/engine";
import { MemoryStore } from "../../lib/jesr/storage";
import { MeshRouter, Transmission, MeshPacket } from "../../lib/mesh/router";
import { makeTestCrypto } from "./test-crypto";

/** Real JesrEngine on A and C, MeshRouter on A-B-C (A<->B, B<->C only); B is a blind relay. */
const link = (r: MeshRouter, peerId: string) => r.observeLink({ peerId, type: "ble", quality: 50, lossPercent: 0, latencyMs: null, stability: 1, lastSeenAt: Date.now() });
const settle = () => new Promise((r) => setTimeout(r, 30));

test("Jesr message A→B→C over MeshRouter data packets; relay sees only ciphertext; ACK returns", async () => {
  const routers: Record<string, MeshRouter> = { A: new MeshRouter("A"), B: new MeshRouter("B"), C: new MeshRouter("C") };
  const adj: Record<string, string[]> = { A: ["B"], B: ["A", "C"], C: ["B"] };
  for (const [n, ps] of Object.entries(adj)) for (const p of ps) link(routers[n], p);
  const relaySeen: MeshPacket[] = [];
  const engines: Record<string, JesrEngine> = {};
  const pump = (from: string, tx: Transmission[]) => {
    for (const t of tx) {
      const packet = JSON.parse(JSON.stringify(t.packet));
      if (t.peerId === "B") relaySeen.push(packet);
      queueMicrotask(() => {
        pump(t.peerId, routers[t.peerId].receive(packet, from));
        for (const d of routers[t.peerId].takeDeliveries()) void engines[t.peerId]?.onEnvelope(JSON.parse(d.packet.payload!.envelope!));
      });
    }
  };
  const mk = async (node: string, name: string) => {
    const e = new JesrEngine(makeTestCrypto(), new MemoryStore(), {
      send: async (env) => { try { const tx = routers[node].sendData(env.to, JSON.stringify(env)); pump(node, tx); return tx.length > 0; } catch { return false; } },
    });
    const p = await e.init(name); routers[node].setAliases([p.jesrId]); engines[node] = e; return { e, id: p.jesrId };
  };
  const a = await mk("A", "A"); const c = await mk("C", "C");
  await a.e.sendFriendRequest(c.id); await settle();
  assert.equal(c.e.requests().length, 1);
  await c.e.accept(a.id); await settle();
  assert.equal(a.e.friends().length, 1);
  await a.e.sendText(c.id, "مرحبا عبر الوسيط"); await settle();
  assert.equal(c.e.history(a.id)[0]?.text, "مرحبا عبر الوسيط");
  assert.equal(a.e.history(c.id)[0]?.status, "delivered");     // signed app ACK came back
  assert.equal(a.e.pendingCount(), 0);
  assert.ok(relaySeen.length > 0);
  assert.ok(!JSON.stringify(relaySeen).includes("مرحبا"));       // relay never saw plaintext
});

test("data packets are rejected when oversized or missing envelope", () => {
  const r = new MeshRouter("A"); link(r, "B");
  assert.throws(() => r.sendData("JESR-X", "x".repeat(5000)));
  const bad: MeshPacket = { id: "p", kind: "data", sourceId: "B", targetId: "A", createdAt: Date.now(), expiresAt: Date.now() + 5000, ttl: 5, hops: 0, path: ["B"] };
  assert.deepEqual(r.receive(bad, "B"), []);
});
