// TEST-ONLY provider built on Node's vetted crypto (Ed25519, X25519, HKDF, AES-256-GCM).
// Not shipped in the app: the app needs a Keystore-backed native provider.
import * as nc from "node:crypto";
import { CryptoProvider } from "../../lib/jesr/crypto-provider";

const rawPub = (k: nc.KeyObject) => Buffer.from(k.export({ format: "jwk" }).x as string, "base64url");
const pubFromRaw = (raw: Uint8Array, type: "ed25519" | "x25519") =>
  nc.createPublicKey({ format: "jwk", key: { kty: "OKP", crv: type === "ed25519" ? "Ed25519" : "X25519", x: Buffer.from(raw).toString("base64url") } });

export function makeTestCrypto(): CryptoProvider {
  const ed = nc.generateKeyPairSync("ed25519");
  const x = nc.generateKeyPairSync("x25519");
  const publicKey = new Uint8Array(Buffer.concat([rawPub(ed.publicKey), rawPub(x.publicKey)]));
  const key = (shared: Buffer, aad: Uint8Array) => Buffer.from(nc.hkdfSync("sha256", shared, Buffer.alloc(0), Buffer.from(aad), 32));
  return {
    publicKey,
    async sign(d) { return new Uint8Array(nc.sign(null, d, ed.privateKey)); },
    async verify(pub, d, sig) { try { return nc.verify(null, d, pubFromRaw(pub.slice(0, 32), "ed25519"), sig); } catch { return false; } },
    async sha256(d) { return new Uint8Array(nc.createHash("sha256").update(d).digest()); },
    async randomBytes(n) { return new Uint8Array(nc.randomBytes(n)); },
    async encrypt(peer, pt, aad) {
      const eph = nc.generateKeyPairSync("x25519");
      const shared = nc.diffieHellman({ privateKey: eph.privateKey, publicKey: pubFromRaw(peer.slice(32), "x25519") });
      const iv = nc.randomBytes(12);
      const ci = nc.createCipheriv("aes-256-gcm", key(shared, aad), iv); ci.setAAD(Buffer.from(aad));
      const ct = Buffer.concat([ci.update(pt), ci.final()]);
      return new Uint8Array(Buffer.concat([rawPub(eph.publicKey), iv, ct, ci.getAuthTag()]));
    },
    async decrypt(_peer, blob, aad) {
      const b = Buffer.from(blob);
      const shared = nc.diffieHellman({ privateKey: x.privateKey, publicKey: pubFromRaw(b.subarray(0, 32), "x25519") });
      const de = nc.createDecipheriv("aes-256-gcm", key(shared, aad), b.subarray(32, 44)); de.setAAD(Buffer.from(aad));
      de.setAuthTag(b.subarray(b.length - 16));
      return new Uint8Array(Buffer.concat([de.update(b.subarray(44, b.length - 16)), de.final()]));
    },
  };
}
