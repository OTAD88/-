import { test } from "node:test";
import assert from "node:assert/strict";
import { JesrEngine, Transport } from "../../lib/jesr/engine";
import { MemoryStore } from "../../lib/jesr/storage";
import { Envelope } from "../../lib/jesr/protocol";
import { deriveJesrId, normalizeJesrId } from "../../lib/jesr/identity";
import { makeTestCrypto } from "./test-crypto";

/** In-process "wire": a hop list A-B-C-D relays opaque envelopes and records what each relay saw. */
class Net {
  nodes = new Map<string, JesrEngine>(); online = new Set<string>(); relaySeen: Envelope[] = []; drop = (_: Envelope) => false;
  transportFor(): Transport {
    return { send: async (env) => {
      if (this.drop(env)) return false;
      this.relaySeen.push(env);                       // every relay can see the envelope, nothing more
      const dst = this.nodes.get(env.to);
      if (!dst || !this.online.has(env.to)) return false;   // no path → not accepted
      void dst.onEnvelope(JSON.parse(JSON.stringify(env)));
      return true;
    } };
  }
}
async function mk(net: Net, name: string, store = new MemoryStore(), c = makeTestCrypto()) {
  const e = new JesrEngine(c, store, net.transportFor());
  const p = await e.init(name);
  net.nodes.set(p.jesrId, e); net.online.add(p.jesrId);
  return { e, id: p.jesrId, c, store };
}
const settle = () => new Promise((r) => setTimeout(r, 20));

test("two identities get distinct, key-bound Jesr IDs", async () => {
  const net = new Net(); const a = await mk(net, "A"); const b = await mk(net, "B");
  assert.notEqual(a.id, b.id);
  assert.equal(a.id, await deriveJesrId(a.c, a.c.publicKey));
  assert.equal(normalizeJesrId(a.id.toLowerCase().replace(/-/g, " ")), a.id);
});

test("friend request → accept; duplicates blocked; no add without consent", async () => {
  const net = new Net(); const a = await mk(net, "A"); const b = await mk(net, "B");
  assert.equal((await a.e.sendFriendRequest(b.id)).ok, true); await settle();
  assert.equal((await a.e.sendFriendRequest(b.id)).reason, "duplicate");
  assert.equal(a.e.friends().length, 0); assert.equal(b.e.friends().length, 0);   // nobody added yet
  assert.equal(b.e.requests().length, 1);
  await b.e.accept(a.id); await settle();
  assert.equal(a.e.friends().length, 1); assert.equal(b.e.friends().length, 1);
  assert.equal(a.e.pendingCount(), 0); assert.equal(b.e.pendingCount(), 0);        // ACKs cleared queues
});

async function befriend(net: Net, a: any, b: any) { await a.e.sendFriendRequest(b.id); await settle(); await b.e.accept(a.id); await settle(); }

test("E2EE message: delivered only after recipient ACK; relay sees ciphertext only", async () => {
  const net = new Net(); const a = await mk(net, "A"); const b = await mk(net, "B"); const relay = makeTestCrypto();
  await befriend(net, a, b);
  const id = await a.e.sendText(b.id, "مرحبا سر"); await settle();
  assert.equal(b.e.history(a.id)[0].text, "مرحبا سر");
  assert.equal(a.e.history(b.id)[0].status, "delivered");
  const wire = net.relaySeen.find((x) => x.id === id)!;
  assert.ok(!JSON.stringify(wire).includes("مرحبا"));
  // an intermediary holding its own keys cannot decrypt
  const { openEnvelope } = await import("../../lib/jesr/protocol");
  const forged = { ...wire, to: "JESR-X" };
  assert.equal((await openEnvelope(relay, "JESR-X", forged, Date.now())).ok, false);
});

test("'sent' ≠ 'delivered': offline peer keeps message queued, then delivers once, once", async () => {
  const net = new Net(); const a = await mk(net, "A"); const b = await mk(net, "B");
  await befriend(net, a, b);
  net.online.delete(b.id);
  await a.e.sendText(b.id, "later"); await settle();
  assert.equal(a.e.history(b.id)[0].status, "sending"); assert.equal(a.e.pendingCount(), 1);
  net.online.add(b.id);
  (a.e as any).clock = () => Date.now() + 10 * 60_000;   // past backoff
  await a.e.flush(); await settle();
  assert.equal(a.e.history(b.id)[0].status, "delivered");
  assert.equal(b.e.history(a.id).length, 1);
});

test("lost ACK → retransmission is de-duplicated and re-ACKed", async () => {
  const net = new Net(); const a = await mk(net, "A"); const b = await mk(net, "B");
  await befriend(net, a, b);
  net.drop = (e) => e.type === "ack";                    // ACKs lost
  await a.e.sendText(b.id, "once"); await settle();
  assert.equal(a.e.history(b.id)[0].status, "sent");     // reached mesh, not confirmed
  net.drop = () => false;
  (a.e as any).clock = () => Date.now() + 10 * 60_000;
  await a.e.flush(); await settle();
  assert.equal(b.e.history(a.id).length, 1);             // no double message
  assert.equal(a.e.history(b.id)[0].status, "delivered");
});

test("forged / replayed / misdirected ACKs are rejected", async () => {
  const net = new Net(); const a = await mk(net, "A"); const b = await mk(net, "B"); const m = await mk(net, "M");
  await befriend(net, a, b);
  net.drop = (e) => e.type === "ack";
  const id = await a.e.sendText(b.id, "x"); await settle();
  // M (a stranger) signs an ACK for A's message id
  const { sealEnvelope } = await import("../../lib/jesr/protocol");
  const fake = await sealEnvelope(m.c, { jesrId: m.id, name: "M" }, { type: "ack", to: a.id, ref: id, now: Date.now() });
  const res: any = await a.e.onEnvelope(fake);
  assert.equal(res.accepted, false);
  assert.notEqual(a.e.history(b.id)[0].status, "delivered");
  // tampered signature
  const tam = { ...fake, ref: "other" };
  assert.equal(((await a.e.onEnvelope(tam)) as any).reason, "bad-signature");
});

test("strangers cannot message; ID/key mismatch rejected", async () => {
  const net = new Net(); const a = await mk(net, "A"); const s = await mk(net, "S");
  const { sealEnvelope } = await import("../../lib/jesr/protocol");
  const env = await sealEnvelope(s.c, { jesrId: s.id, name: "S" }, { type: "msg", to: a.id, plaintext: "hi", peerPub: a.c.publicKey, now: Date.now() });
  assert.equal(((await a.e.onEnvelope(env)) as any).accepted, false);
  assert.equal(a.e.history(s.id).length, 0);
  const spoof = { ...env, from: a.id.replace(/.$/, "0") };
  assert.equal(((await a.e.onEnvelope(spoof)) as any).reason, "id-key-mismatch");
});

test("state survives restart (persisted store + queue)", async () => {
  const net = new Net(); const store = new MemoryStore(); const a = await mk(net, "A", store); const b = await mk(net, "B");
  await befriend(net, a, b); net.online.delete(b.id);
  await a.e.sendText(b.id, "persist me");
  const a2 = new JesrEngine(a.c, store, net.transportFor()); await a2.init("ignored");
  assert.equal(a2.profile.jesrId, a.id);
  assert.equal(a2.history(b.id)[0].text, "persist me"); assert.equal(a2.pendingCount(), 1);
});
