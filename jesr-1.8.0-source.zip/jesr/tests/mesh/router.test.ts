import { describe, expect, it } from "vitest";
import { MeshRouter, type MeshPacket } from "../../lib/mesh/router";

function connected(a: MeshRouter, b: MeshRouter, time: () => number, idA: string, idB: string, type: "ble" | "wifi-direct" = "wifi-direct") {
  const metrics = (peerId: string) => ({
    peerId,
    type,
    quality: 90,
    lossPercent: 0,
    latencyMs: 15,
    stability: 0.95,
    qualityMeasured: true,
    lossMeasured: true,
    stabilityMeasured: true,
    lastSeenAt: time(),
  });
  a.observeLink(metrics(idB));
  b.observeLink(metrics(idA));
}

describe("Jesr mesh router", () => {
  it("delivers a ping A→C through B without a direct A-C link and returns an ACK", () => {
    let now = 1_000;
    let sequence = 0;
    const time = () => now;
    const packetId = () => `pkt-${++sequence}`;
    const a = new MeshRouter("A", { now: time, packetId });
    const b = new MeshRouter("B", { now: time, packetId });
    const c = new MeshRouter("C", { now: time, packetId });
    connected(a, b, time, "A", "B");
    connected(b, c, time, "B", "C");

    const queue: Array<{ from: string; to: string; packet: MeshPacket }> = [];
    const routers = new Map([["A", a], ["B", b], ["C", c]]);
    const enqueue = (from: string, transmissions: ReturnType<MeshRouter["sendPing"]>) => {
      for (const transmission of transmissions) queue.push({ from, to: transmission.peerId, packet: transmission.packet });
    };
    enqueue("A", a.sendPing("C"));
    const observedPath: string[][] = [];
    let steps = 0;
    while (queue.length && steps++ < 20) {
      const frame = queue.shift()!;
      const router = routers.get(frame.to)!;
      const outgoing = router.receive(frame.packet, frame.from);
      if (router === c && frame.packet.kind === "ping") observedPath.push([...frame.packet.path, "C"]);
      enqueue(frame.to, outgoing);
    }

    expect(steps).toBeLessThan(20);
    expect(observedPath).toEqual([["A", "B", "C"]]);
    expect(a.getSnapshot().events.some((event) => event.kind === "ping_ack")).toBe(true);
    expect(a.getSnapshot().routes.find((route) => route.destinationId === "C")?.nextHopId).toBe("B");
    expect(a.getSnapshot().routes.find((route) => route.destinationId === "C")?.hops).toBe(2);
    expect(a.getSnapshot().events.find((event) => event.kind === "ping_ack")?.path).toEqual(["A", "B", "C"]);
  });

  it("delivers across a mixed BLE → Wi-Fi Direct path", () => {
    let now = 2_000;
    let sequence = 0;
    const time = () => now;
    const packetId = () => `mixed-${++sequence}`;
    const a = new MeshRouter("A", { now: time, packetId });
    const b = new MeshRouter("B", { now: time, packetId });
    const c = new MeshRouter("C", { now: time, packetId });
    connected(a, b, time, "A", "B", "ble");
    connected(b, c, time, "B", "C", "wifi-direct");

    const queue: Array<{ from: string; to: string; packet: MeshPacket }> = [];
    const routers = new Map([['A', a], ['B', b], ['C', c]]);
    const enqueue = (from: string, transmissions: ReturnType<MeshRouter["sendPing"]>) => {
      for (const transmission of transmissions) queue.push({ from, to: transmission.peerId, packet: transmission.packet });
    };
    enqueue("A", a.sendPing("C"));
    let delivered = false;
    for (let steps = 0; queue.length && steps < 20; steps += 1) {
      const frame = queue.shift()!;
      const router = routers.get(frame.to)!;
      if (router === c && frame.packet.kind === "ping") delivered = true;
      enqueue(frame.to, router.receive(frame.packet, frame.from));
    }
    expect(delivered).toBe(true);
    expect(a.getSnapshot().events.some((event) => event.kind === "ping_ack")).toBe(true);
  });

  it("reroutes through an alternate path after the preferred next hop disappears", () => {
    let now = 3_000;
    let sequence = 0;
    const time = () => now;
    const packetId = () => `failover-${++sequence}`;
    const a = new MeshRouter("A", { now: time, packetId });
    const b = new MeshRouter("B", { now: time, packetId });
    const c = new MeshRouter("C", { now: time, packetId });
    const d = new MeshRouter("D", { now: time, packetId });
    connected(a, b, time, "A", "B");
    connected(b, c, time, "B", "C");
    connected(a, d, time, "A", "D");
    connected(d, c, time, "D", "C");
    const first = a.sendPing("C");
    expect(first.map((item) => item.peerId)).toContain("B");
    a.removeLink("B");
    expect(a.sendPing("C").map((item) => item.peerId)).toContain("D");
  });

  it("suppresses duplicate packets and prevents forwarding loops", () => {
    let now = 10_000;
    const time = () => now;
    const a = new MeshRouter("A", { now: time, packetId: () => "unused" });
    const b = new MeshRouter("B", { now: time, packetId: () => "unused" });
    const c = new MeshRouter("C", { now: time, packetId: () => "unused" });
    connected(a, b, time, "A", "B");
    connected(b, c, time, "B", "C");
    const packet: MeshPacket = {
      id: "same-packet",
      kind: "ping",
      sourceId: "A",
      targetId: "not-here",
      createdAt: now,
      expiresAt: now + 10_000,
      ttl: 5,
      hops: 0,
      path: ["A"],
    };
    const first = b.receive(packet, "A");
    const second = b.receive(packet, "A");
    expect(first.map((item) => item.peerId)).toEqual(["C"]);
    expect(second).toEqual([]);
    expect(c.receive({ ...packet, path: ["A", "B"] }, "B")).toEqual([]);
  });

  it("queues a packet only when no usable neighbor exists and expires it", () => {
    let now = 20_000;
    let sequence = 0;
    const router = new MeshRouter("A", {
      now: () => now,
      packetId: () => `q-${++sequence}`,
      packetLifetimeMs: 1_000,
    });
    expect(router.sendPing("B")).toEqual([]);
    expect(router.getSnapshot().pendingPackets).toBe(1);
    now += 1_500;
    router.getSnapshot();
    expect(router.getSnapshot().pendingPackets).toBe(0);
    expect(router.getSnapshot().events.some((event) => event.kind === "queue_expired")).toBe(true);
  });

  it("does not use unmeasured placeholder quality, loss or stability in route scoring", () => {
    const router = new MeshRouter("A", { now: () => 40_000 });
    router.observeLink({
      peerId: "B", type: "wifi-direct", quality: 0, lossPercent: 100, latencyMs: null, stability: 0, lastSeenAt: 40_000,
    });
    const route = router.getSnapshot().routes.find((item) => item.destinationId === "B");
    expect(route?.score).toBe(100);
    expect(route?.qualityMeasured).toBe(false);
    expect(route?.lossMeasured).toBe(false);
    expect(route?.stabilityMeasured).toBe(false);
  });

  it("rejects packets with an exhausted TTL or expired timestamp", () => {
    const router = new MeshRouter("B", { now: () => 30_000 });
    router.observeLink({
      peerId: "A", type: "ble", quality: 80, lossPercent: 0, latencyMs: null, stability: 0.8, lastSeenAt: 30_000,
    });
    const expired: MeshPacket = {
      id: "old", kind: "ping", sourceId: "A", targetId: "B", createdAt: 1, expiresAt: 2,
      ttl: 4, hops: 0, path: ["A"],
    };
    expect(router.receive(expired, "A")).toEqual([]);
    expect(router.getSnapshot().events.some((event) => event.kind === "routing_failed")).toBe(true);
  });

  it("rejects a packet whose declared path does not end at the ingress peer", () => {
    const router = new MeshRouter("C", { now: () => 50_000 });
    router.observeLink({
      peerId: "B", type: "ble", quality: 80, lossPercent: 0, latencyMs: null, stability: 0.8, lastSeenAt: 50_000,
    });
    const packet: MeshPacket = {
      id: "bad-path", kind: "ping", sourceId: "A", targetId: "D", createdAt: 50_000,
      expiresAt: 60_000, ttl: 4, hops: 1, path: ["A", "X"],
    };
    expect(router.receive(packet, "B")).toEqual([]);
    expect(router.getSnapshot().events.some((event) => event.kind === "routing_failed")).toBe(true);
  });
});
