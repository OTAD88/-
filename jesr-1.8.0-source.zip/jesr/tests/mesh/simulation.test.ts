import { describe, expect, it } from "vitest";
import { MeshSimulation } from "../../lib/mesh/simulation";

describe("Network Simulation Lab", () => {
  it("delivers through a mixed transport chain", () => {
    const simulation = new MeshSimulation(3, "chain", () => 1_000);
    simulation.send("SIM-001", "SIM-003");
    const snapshot = simulation.snapshot();
    expect(snapshot.stats.packetsSent).toBe(1);
    expect(snapshot.stats.packetsDelivered).toBe(1);
    expect(snapshot.lastPath).toEqual(["SIM-001", "SIM-002", "SIM-003"]);
    expect(snapshot.stats.averageHops).toBe(2);
  });

  it("records a failed delivery when an intermediate node is offline", () => {
    const simulation = new MeshSimulation(3, "chain", () => 2_000);
    simulation.setNodeOnline("SIM-002", false);
    simulation.send("SIM-001", "SIM-003");
    const snapshot = simulation.snapshot();
    expect(snapshot.stats.packetsSent).toBe(1);
    expect(snapshot.stats.packetsDelivered).toBe(0);
    expect(snapshot.stats.packetsLost).toBeGreaterThan(0);
  });

  it("supports a larger virtual network without fabricating delivery metrics", () => {
    const simulation = new MeshSimulation(100, "random", () => 3_000);
    const snapshot = simulation.snapshot();
    expect(snapshot.stats.devices).toBe(100);
    expect(snapshot.stats.connections).toBeGreaterThan(0);
    expect(snapshot.stats.packetsSent).toBe(0);
    expect(snapshot.stats.deliveryRate).toBe(0);
  });
});
