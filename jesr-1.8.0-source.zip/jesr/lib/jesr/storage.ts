/**
 * Persistence Layer boundary. Production implementation must be encrypted at
 * rest (e.g. SQLCipher with a key wrapped by Android Keystore). Not implemented
 * natively yet; MemoryStore is for tests only.
 */
export interface KeyValueStore {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
}
export class MemoryStore implements KeyValueStore {
  m = new Map<string, string>();
  async get(k: string) { return this.m.get(k) ?? null; }
  async set(k: string, v: string) { this.m.set(k, v); }
}
