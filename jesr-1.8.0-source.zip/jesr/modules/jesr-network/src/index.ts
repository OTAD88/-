import { requireNativeModule, type NativeModule } from "expo";
import { Platform } from "react-native";

export type JesrTransport = "ble" | "wifi-direct";
export type JesrMode = "balanced" | "battery";

export interface JesrPeer {
  id: string;
  transport: JesrTransport;
  direct: boolean;
  quality: number;
  qualityMeasured: boolean;
  lossPercent: number;
  lossMeasured: boolean;
  latencyMs: number | null;
  stability: number;
  stabilityMeasured: boolean;
  rssiDbm?: number;
  lastSeenAt: number;
  connected: boolean;
}

export interface JesrRoute {
  destinationId: string;
  nextHopId: string;
  hops: number;
  quality: number;
  qualityMeasured: boolean;
  lossPercent: number;
  lossMeasured: boolean;
  latencyMs: number | null;
  stability: number;
  stabilityMeasured: boolean;
  lastUpdatedAt: number;
}

export interface JesrLogEvent {
  id: string;
  at: number;
  kind: string;
  message: string;
  nodeId?: string;
  packetId?: string;
  path?: string[];
  rttMs?: number;
  success?: boolean;
}

export interface JesrSnapshot {
  available: boolean;
  active: boolean;
  localId: string;
  transportState: string;
  batteryMode: JesrMode;
  peers: JesrPeer[];
  routes: JesrRoute[];
  pendingPackets: number;
  events: JesrLogEvent[];
}

interface JesrEvents extends Record<string, (...args: any[]) => void> {
  onMeshState: (snapshot: JesrSnapshot) => void;
  onMeshLog: (event: JesrLogEvent) => void;
  onPeerDiscovered: (peer: JesrPeer) => void;
  onPingResult: (event: JesrLogEvent & { success: boolean; rttMs?: number }) => void;
  onJesrData: (event: { envelope: string }) => void;
}

declare class JesrNetworkNative extends NativeModule<JesrEvents> {
  getSnapshot(): Promise<JesrSnapshot>;
  getNativeDiagnosticReport(): Promise<string>;
  startNetwork(mode: JesrMode): Promise<JesrSnapshot>;
  stopNetwork(): Promise<JesrSnapshot>;
  discoverPeers(): Promise<void>;
  connectPeer(peerId: string): Promise<void>;
  sendPing(peerId: string): Promise<string>;
  setJesrId(jesrId: string): Promise<void>;
  sendData(targetJesrId: string, envelope: string): Promise<boolean>;
  cryptoPublicKey(): Promise<string>;
  cryptoSign(dataB64: string): Promise<string>;
  cryptoVerify(pubB64: string, dataB64: string, sigB64: string): Promise<boolean>;
  cryptoSha256(dataB64: string): Promise<string>;
  cryptoRandom(n: number): Promise<string>;
  cryptoEncrypt(peerPubB64: string, plainB64: string, aadB64: string): Promise<string>;
  cryptoDecrypt(blobB64: string, aadB64: string): Promise<string>;
  secureGet(name: string): Promise<string | null>;
  secureSet(name: string, value: string): Promise<void>;
}

let nativeModule: JesrNetworkNative | null = null;

if (Platform.OS === "android") {
  try {
    nativeModule = requireNativeModule<JesrNetworkNative>("JesrNetwork");
  } catch {
    // Expo Go and web preview intentionally have no custom native mesh module.
  }
}

export const isJesrNativeAvailable = nativeModule !== null;

export function addMeshListener<K extends keyof JesrEvents>(
  eventName: K,
  listener: JesrEvents[K],
) {
  return nativeModule?.addListener(eventName, listener) ?? { remove() {} };
}

function requireNative(): JesrNetworkNative {
  if (!nativeModule) {
    throw new Error("يتطلب تشغيل BLE وWi‑Fi Direct تثبيت بناء Android أصلي مخصص، ولا يعمل في Expo Go أو معاينة الويب.");
  }
  return nativeModule;
}

export async function getMeshSnapshot(): Promise<JesrSnapshot> {
  if (!nativeModule) {
    return {
      available: false,
      active: false,
      localId: "غير متاح",
      transportState: "يتطلب بناء Android أصلي",
      batteryMode: "balanced",
      peers: [],
      routes: [],
      pendingPackets: 0,
      events: [],
    };
  }
  return nativeModule.getSnapshot();
}

export function getNativeDiagnosticReport() {
  return nativeModule?.getNativeDiagnosticReport() ?? Promise.resolve("Native diagnostics unavailable in preview.");
}

export function startMesh(mode: JesrMode) {
  return requireNative().startNetwork(mode);
}

export function stopMesh() {
  return requireNative().stopNetwork();
}

export function discoverMeshPeers() {
  return requireNative().discoverPeers();
}

export function connectMeshPeer(peerId: string) {
  return requireNative().connectPeer(peerId);
}

export function sendMeshPing(peerId: string) {
  return requireNative().sendPing(peerId);
}

/** Tells the native router which Jesr ID this device answers to for `data` packets. */
export function setJesrId(jesrId: string) {
  return requireNative().setJesrId(jesrId);
}

/** Resolves true iff at least one live mesh link accepted the frame. Never means delivered. */
export function sendJesrData(targetJesrId: string, envelope: string) {
  return requireNative().sendData(targetJesrId, envelope);
}

export function addJesrDataListener(listener: (envelope: string) => void) {
  return addMeshListener("onJesrData", (e) => listener(e.envelope));
}

/** Raw native crypto/storage bridge (base64 in/out). Use createNativeCrypto() instead of calling this directly. */
export function nativeBridge(): JesrNetworkNative {
  return requireNative();
}
